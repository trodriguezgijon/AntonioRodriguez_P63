/**
* Clase que define lo que es una fabrica y crea objetos coche.
* 
* @author Antonio Rodriguez Gijon
* @version 1.1
*/
import javax.swing.JOptionPane;
public class Fabrica{
/**
* Metodo main, en el cual existe un menu que da las opciones.
*
* @param args Lineas del programa
*/
	public static void main (String [] args){
		Coche [] almacen = new Coche [Coche.getMaxCoches()];
		boolean salir = false;
		int opcion = 0;
		String matriculabuscar = "";
		int auxiliar = 0;
		do{
			try{
				opcion = Integer.parseInt(JOptionPane.showInputDialog(null, "Fabrica de Coches Antonio Rodriguez S.L. \n Selecciona una de las siguientes opciones:\n 1. Fabricar coche (conociendo matricula)\n 2. Fabricar coche (a partir del numero de puertas y el numero de plazas)\n 3. Fabricar coche (a partir de la marca, el modelo y el color)\n 4. Fabricar coche (sin datos)\n 5. Tunear coche (pintandolo de un color)\n 6. Tunear coche (sin pintarlo)\n 7. Avanzar km\n 8. Mostrar caracteristicas de un coche\n 9. Salir del programa\n"));
			}
			catch(Exception e){
				JOptionPane.showMessageDialog(null, "La opcion elegida no es numerica");
			}
			switch(opcion){
				case 1:
					if(Coche.getNumCoches() == Coche.getMaxCoches()){
						JOptionPane.showMessageDialog(null, "Almacen lleno, no es posible almacenar ningun vehiculo mas");
					}
					else{
						almacen[Coche.getNumCoches()] = new Coche(JOptionPane.showInputDialog(null, "Introduzca matricula:"));
						caracteristicas(almacen[Coche.getNumCoches() - 1]);
					}
					break;
				case 2:
					if(Coche.getNumCoches() == Coche.getMaxCoches()){
						JOptionPane.showMessageDialog(null, "Almacen lleno, no es posible almacenar ningun vehiculo mas");
					}
					else{
						almacen[Coche.getNumCoches()] = new Coche(Integer.parseInt(JOptionPane.showInputDialog(null, "Introduzca numero de puertas")),Integer.parseInt(JOptionPane.showInputDialog(null, "Introduzca numero de plazas:")));
						almacen[Coche.getNumCoches() - 1].matricular(matAleatoria());
						caracteristicas(almacen[Coche.getNumCoches() - 1]);
					}
					break;
				case 3:
					if(Coche.getNumCoches() == Coche.getMaxCoches()){
						JOptionPane.showMessageDialog(null, "Almacen lleno, no es posible almacenar ningun vehiculo mas");
					}
					else{
						almacen[Coche.getNumCoches()] = new Coche(JOptionPane.showInputDialog(null, "Introduzca la marca:"),JOptionPane.showInputDialog(null, "Introduzca el modelo:"),JOptionPane.showInputDialog(null, "Introduzca el color:"));
						almacen[Coche.getNumCoches() - 1].matricular(matAleatoria());
						caracteristicas(almacen[Coche.getNumCoches() - 1]);
					}
					break;
				case 4:
					if(Coche.getNumCoches() == Coche.getMaxCoches()){
						JOptionPane.showMessageDialog(null, "Almacen lleno, no es posible almacenar ningun vehiculo mas");
					}
					else{
						almacen[Coche.getNumCoches()] = new Coche();
						almacen[Coche.getNumCoches() - 1].matricular(matAleatoria());
						caracteristicas(almacen[Coche.getNumCoches() - 1]);
					}
					break;
				case 5:
					matriculabuscar = JOptionPane.showInputDialog(null, "Introduzca la matricula del coche a tunear y pintar");
					auxiliar = buscaCoche(almacen, matriculabuscar);
					if(auxiliar == -1){
						JOptionPane.showMessageDialog(null, "La matricula especificada no ha sido encontrada");
					}
					else{
						almacen[auxiliar].tunear(JOptionPane.showInputDialog(null, "De que color quieres pintar el coche?"));
					}
					break;
				case 6:
					matriculabuscar = JOptionPane.showInputDialog(null, "Introduzca la matricula del coche a tunear:");
					auxiliar = buscaCoche(almacen, matriculabuscar);
					if(auxiliar == -1){
						JOptionPane.showMessageDialog(null, "La matricula especificada no ha sido encontrada");
					}
					else{
						almacen[auxiliar].tunear();
					}
					break;
				case 7:
					matriculabuscar = JOptionPane.showInputDialog(null, "Introduzca la matricula del coche para avanzar cuentakilometros:");
					auxiliar = buscaCoche(almacen, matriculabuscar);
					if(auxiliar == -1){
						JOptionPane.showMessageDialog(null, "La matricula especificada no ha sido encontrada");
					}
					else{
						almacen[auxiliar].avanzar(Double.parseDouble(JOptionPane.showInputDialog(null,"Cuantos kilometros deseas avanzar?")));
					}
					break;
				case 8:
					matriculabuscar = JOptionPane.showInputDialog(null, "Introduzca la matricula del coche para mostrar:");
					auxiliar = buscaCoche(almacen, matriculabuscar);
					if(auxiliar == -1){
						JOptionPane.showMessageDialog(null, "La matricula especificada no ha sido encontrada");
					}
					else{
						caracteristicas(almacen[auxiliar]);
					}
					break;
				case 9:
					salir = true;
					JOptionPane.showMessageDialog(null, "Gracias por utilizar este programa. \n Un saludo Antonio");
					break;
				default:
					JOptionPane.showMessageDialog(null, "La opci\u00f3n elegida no existe");	
					break;
			}
		}while(salir == false);
	}
/**
* Metodo que devuelve una matricula aleatoria.
*
* @return Matricula devuelta.
*/
	public static String matAleatoria(){
		String aux = Integer.toString((int)(100000 * Math.random()));
		return aux;
	}
/**
* Metodo que busca los coches almacenados en el array.
* 
* @param coches Array que almacena todos los objetos coches creados hasta el momento.
* @param matri MAtricula que vamos a buscar dentro del array.
* @return Posicion donde se encuentra el vehiculo. 
*/
	public static int buscaCoche(Coche[] coches, String matri){
		int encontrado = -1;
			for(int j = 0; j < coches.length; j++){
				if(coches[j] != null && matri.equals(coches[j].getMatricula())){
					encontrado = j;
					return encontrado;
				}
			}
		return encontrado;
	}
/**
* Metodo que muestra todas las caracteristicas de un coche.
*
* @param car Coche del cual vamos a mostrar sus caracteristicas.
*/
	public static void caracteristicas(Coche car){
		String s;
		if(car.getTechoSolar() == true)
			s = "Si";
		else
			s = "No";
		JOptionPane.showMessageDialog(null, "Matricula " + car.getMatricula() + "\n Marca: " + car.getMarca() + "\n Modelo: " + car.getModelo() + "\n Color: " + car.getColor() + "\n Techo Solar: " + s + "\n Kilometros: " + car.getKilometros() + "\n Numero de Puertas: " + car.getNumPuertas() + "\n Numero de Plazas: " + car.getNumPlazas());
	}

}