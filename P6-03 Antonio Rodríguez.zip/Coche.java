/**
* Clase que define lo que es un coche y 
* sus variables de instancia.
* 
* @author Antonio Rodriguez Gijon
* @version 1.1
*/
public class Coche{
	private String matricula = null; // Matricula del coche
	private String marca = "SEAT"; //Marca del coche
	private String modelo = "ALTEA"; //Modelo del coche
	private String color = "Blanco"; //Color del coche
	private boolean techoSolar = false; //Propiedad de tener techo solar
	private double kilometros = 0; //Kilometros actuales del coche
	private int numPuertas = 3; //Cantidad de puertas del coche
	private int numPlazas = 5; //Cantidad de plazas del coche
	private static int numCoches = 0; //Cantidad de coches creados
	public static final int maxCoches = 5; //Maximo de coches que se pueden crear
/**
* Este metodo crea un coche con sus valores por defecto
*/
	public Coche(){
		numCoches++;
	}
/**
* Este metodo crea un coche, pide por parametros:
* @param mat Matricula a asignar
*/	
	public Coche(String mat){
		setMatricula(mat);
		numCoches++;
	}
/**
* Este metodo crea un coche, pide por parametros:
* @param numPue Numero de puertas a asignar al coche
* @param numPla Numero de plazas a asignar al coche
*/
	public Coche(int numPue, int numPla){
		setNumPuertas(numPue);
		setNumPlazas(numPla);
		numCoches++;
	}
/**
* Este metodo crea un coche, pide por parametros:
* @param marc Marca a asignar al coche
* @param model Modelo a asignar al coche
* @param colour Color a asignar al coche
*/			
	public Coche(String marc, String model, String colour){
		setMarca(marc);
		setModelo(model);
		setColor(colour);
		numCoches++;
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public String getMatricula(){
		return matricula;
	}
/**
* Metodo set que asigna el valor pasado por parametro al coche
* @param mat MAtricula a asignar
*/	
	public void setMatricula(String mat){
		matricula = mat;
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public String getMarca(){
		return marca;
	}
/**
* Metodo set que asigna el valor pasado por parametro al coche
* @param mar Marca a asignar
*/
	public void setMarca(String mar){
		marca = mar;
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public String getModelo(){
		return modelo;
	}
/**
* Metodo set que asigna el valor pasado por parametro al coche
* @param mod Modelo a asignar
*/	
	public void setModelo(String mod){
		modelo = mod;
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public String getColor(){
		return color;
	}
/**
* Metodo set que asigna el valor pasado por parametro al coche
* @param col Color a asignar
*/	
	public void setColor(String col){
		color = col;
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public boolean getTechoSolar(){
		return techoSolar;
	}
/**
* Metodo set que asigna el valor pasado por parametro al coche
* @param boo Booleano que define si existe techo solar.
*/	
	public void setTechoSolar(boolean boo){
		techoSolar = boo;
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public double getKilometros(){
		return kilometros;
	}
/**
* Metodo set que asigna el valor pasado por parametro al coche
* @param km Kilometros a asignar a coche.
*/	
	public void setKilometros(double km){
		if(km > 0){
			kilometros = km;
		}
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public int getNumPuertas(){
		return numPuertas;
	}
/**
* Metodo set que asigna el valor pasado por parametro al coche
* @param doors Puertas a asignar
*/	
	public void setNumPuertas(int doors){
		if(doors <= 5 && doors > 0)
			numPuertas = doors;	
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public int getNumPlazas(){
		return numPlazas;
	}
/**
* Metodo set que asigna el valor pasado por parametro al coche
* @param plaza Plazas a asignar
*/	
	public void setNumPlazas(int plaza){
		if(plaza <= 7 && plaza > 0)
			numPlazas = plaza;
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public static int getMaxCoches(){
		return maxCoches;
	}
/**
* Metodo get que devuelve el valor asignado a una de las propiedad del coche
*/	
	public static int getNumCoches(){
		return numCoches;
	}
/**
* Metodo que avanza los kilometros del coche
* @param kilometro Asigna los kilometros definidos al coche
*/
	public void avanzar(double kilometro){
		setKilometros(getKilometros() + kilometro);
	}
/**
* Metodo que añade techo solar y deja kilometros a 0.
*/
	public void tunear(){
		if(getTechoSolar() == true){
			setKilometros(0);
		}
		else{
			setTechoSolar(true);
			setKilometros(0);
		}
	}
/**
* Metodo que añade techo solar, pinta el coche y deja kilometros a 0.
*@param colo Color al que se va a pintar el coche.
*/
	public void tunear(String colo){
		if(getTechoSolar() == true){
			setKilometros(0);
			setColor(colo);
		}
		else{
			setTechoSolar(true);
			setKilometros(0);
			setColor(colo);
		}
	}
/**
* Metodo que añade matricula al coche.
*@param matri Matricula que se va a añadir al coche.
*/
	public void matricular(String matri){
		setMatricula(matri);
	}

}