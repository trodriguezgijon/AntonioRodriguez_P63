import javax.swing.JOptionPane;
public class Fabrica{
	public static void main (String [] args){
		JOptionPane.showMessageDialog(null, "Fabrica de Coches. \n Tema: 6 Practica: 3 \n Por: Antonio Rodriguez ");
		Coche [] coches = new Coche [4];
		Coche car1 = new Coche();
		Coche car2 = new Coche("5678-AG");
		Coche car3 = new Coche("BMW", "850", "Gris");
		Coche car4 = new Coche(5,7);
		car2.setMarca("Fiat");
		car4.setMarca("VW");
		car1.setModelo("Toledo");
		car2.setModelo("Uno");
		car4.setModelo("Caddy");
		car1.setColor("Azul");
		car3.setNumPuertas(5);
		car2.setNumPlazas(2);
		car1.matricular("1234-DF");
		car3.matricular("9012-HH");
		car4.matricular("3456-XS");
		car2.tunear("Rojo");
		car4.tunear();
		car1.avanzar(200);
		car2.avanzar(300);
		car3.avanzar(400);
		car4.avanzar(500);
		coches[0] = car1;
		coches[1] = car2;
		coches[2] = car3;
		coches[3] = car4;
		for(Coche car:coches){
			caracteristicas(car);
		}
	}
	public static void caracteristicas (Coche car){
		String s;
		if(car.getTechoSolar() == true)
			s = "Si";
		else
			s = "No";
		JOptionPane.showMessageDialog(null, "Matricula " + car.getMatricula() + "\n Marca: " + car.getMarca() + "\n Modelo: " + car.getModelo() + "\n Color: " + car.getColor() + "\n Techo Solar: " + s + "\n Kilometros: " + car.getKilometros() + "\n Numero de Puertas: " + car.getNumPuertas() + "\n Numero de Plazas: " + car.getNumPlazas());
	}
}