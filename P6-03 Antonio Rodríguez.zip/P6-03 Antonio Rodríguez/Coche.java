import javax.swing.JOptionPane;
public class Coche{
	private String matricula = null;
	private String marca = "SEAT";
	private String modelo = "ALTEA";
	private String color = "Blanco";
	private boolean techoSolar = false;
	private double kilometros = 0;
	private int numPuertas = 3;
	private int numPlazas = 5;
	public Coche(){
	}
	public Coche(String mat){
		setMatricula(mat);
	}
	public Coche(int numPue, int numPla){
		setNumPuertas(numPue);
		setNumPlazas(numPla);
	}
	public Coche(String marc, String model, String colour){
		setMarca(marc);
		setModelo(model);
		setColor(colour);
	}
	public String getMatricula(){
		return matricula;
	}
	public void setMatricula(String mat){
		matricula = mat;
	}
	public String getMarca(){
		return marca;
	}
	public void setMarca(String mar){
		marca = mar;
	}
	public String getModelo(){
		return modelo;
	}
	public void setModelo(String mod){
		modelo = mod;
	}
	public String getColor(){
		return color;
	}
	public void setColor(String col){
		color = col;
	}
	public boolean getTechoSolar(){
		return techoSolar;
	}
	public void setTechoSolar(boolean boo){
		techoSolar = boo;
	}
	public double getKilometros(){
		return kilometros;
	}
	public void setKilometros(double km){
		if(km > 0){
			kilometros = km;
		}
	}
	public int getNumPuertas(){
		return numPuertas;
	}
	public void setNumPuertas(int doors){
		if(doors <= 5 && doors > 0)
			numPuertas = doors;	
	}
	public int getNumPlazas(){
		return numPlazas;
	}
	public void setNumPlazas(int plaza){
		if(plaza <= 7 && plaza > 0)
			numPlazas = plaza;
	}
	public void avanzar(double kilometro){
		setKilometros(getKilometros() + kilometro);
		JOptionPane.showMessageDialog(null, "Kilometros actualizados a " + getKilometros() +" km por el mecanico.");
	}
	public void tunear(){
		if(getTechoSolar() == true){
			setKilometros(0);
			JOptionPane.showMessageDialog(null, "Kilometros actualizados a " + getKilometros() +" km por el mecanico. Techo Solar ya instalado.");
		}
		else{
			setTechoSolar(true);
			setKilometros(0);
			JOptionPane.showMessageDialog(null, "Kilometros actualizados a " + getKilometros() +" km por el mecanico. \n Instalado Techo Solar.");
		}
	}
	public void tunear(String colo){
		if(getTechoSolar() == true){
			setKilometros(0);
			setColor(colo);
			JOptionPane.showMessageDialog(null, "Kilometros actualizados a " + getKilometros() +" km por el mecanico. \n Pintado el coche de " + getColor() + "Techo Solar ya instalado.");
		}
		else{
			setTechoSolar(true);
			setKilometros(0);
			setColor(colo);
			JOptionPane.showMessageDialog(null, "Kilometros actualizados a " + getKilometros() +" km por el mecanico. \n Pintado el coche de " + getColor() + "\n Instalado Techo Solar.");
		}
	}
	public void matricular(String matri){
		setMatricula(matri);
		JOptionPane.showMessageDialog(null, "Coche matriculado con la siguiente matricula " + getMatricula());
	}
}